***********************************************************************
AFP v2.0 - README

For mIRC 5.7 or above
Created by W\RRIOR - 2000
***********************************************************************
     CAUTION!! - Unload & delete old AFP files before installing!
***********************************************************************

HOW TO INSTALL

Important Note: Do not install afp2.ini as it will automatically
load after afp.ini is loaded. Both afp.ini and afp2.ini must be
in same directory. It doesn't matter which directory they are in
as long as they are both together. If afp2.ini is missing or in
another directory, afp.ini will unload itself.

In any mIRC editbox use the following example:

/load -rs afp.ini

For loading AFP from different directory than your current mIRC
directory use the following example:

/load -rs c:\windows\afp.ini

***********************************************************************
Created by W\RRIOR - 2000
Email: texnwar@hotmail.com