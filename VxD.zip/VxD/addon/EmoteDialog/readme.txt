;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;                                         ;;;;;
;;;;;  EmoteDialog v1.0 for ChatCore by SEC.  ;;;;; 
;;;;;                                         ;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

This emote dialog is completely a DCX build and is version 1.0. Thanks to Paige for the idea, Paul and Randy for their help and assistance in getting it to function properly.

This snippet was built in mIRC 7.22 and using a dev build of dcx.dll, in order to use it in older mirc prior to 7 you will have to swap the dcx.dll out for the Current Supported Release of DCX. You can find a copy here: http://dcx.scriptsdb.org/ along with support and other info about DCX.


** How to set up: **

Copy the EmoteDialog folder to your main script folder.
type /load -rs EmoteDialog\EmoteDialog.mrc or in the script editor on the remote tab, click File>Load...> then navigate to the EmoteDialog folder and click on the EmoteDialog.mrc file then click Open.

If you are using another DCX addon such as the webchat or nicklist by Gabriel and Paul, you will need to delete the 3 dcx aliases at the bottom of the EmoteDialog.mrc file in order to avoid any conflicts loading the dcx.dll.

If you have any questions or need help, find me on https://www.chatcore.com. I'm usually in #Geeks, #Dev, and #HiddenCove.

Thanks for trying out my first DCX project.

Scott (SEC)

