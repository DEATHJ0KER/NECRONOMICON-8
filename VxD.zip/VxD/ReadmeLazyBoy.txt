Re-Released on October 27, 2002

Thank you for downloading and having an interest in my Lazy Boy Addon
(Formally known as Talk-aholic Addon).

###############
# Description #
###############

This is a simple yet effective acronym replacer that completes your normal
acronyms like "bbl" turns into "Be Back Later".  This will complete any and
every occurence of bbl in your line that you typed.  This also has the feature
of colour stripping.  If the channel where you talk is +c (No colour
permitted), the script will strip all colour and STILL complete the acronyms.

For a full list on what it is capable of, refer to the accompaning text entitled
"LazyBoy-Acronyms.txt"


###############################################################################
#                                   WARNING                                   #
###############################################################################

This script MAY have conflicts with other scripts.  If you experience double
talk (IE you type lol, hit enter and it says lol and "Laughing Out Loud" right
after or right before) you have another script that has an On Input: statement.
I don't have any other solutions but to unload or comment out the on input
statement in THAT script in order to use mine.

################
# Installation #
################

To load this addon, copy it and the LazyBoy-Acronyms.txt to the mIRC directory
where the mirc32.exe is located, start mIRC and type:

/load -rs LazyBoy.mrc

I have revamped my old script as frankly it sucked and was gay.  Please do not
rip part or all of this script as a lot of hard work has gone into it.

Thank you

OverDrive
overdrive@adamj.org
http://www.adamj.org


############
# UPDATES: #
############

10/29/2002 - Wow, already an update.  Someone found a missing comma in one of
             the lines *Fixed*.  I decided to make the menus a bit easier for
             use.  I also added the ability to turn the addon off and on,
             depending on your mood.  I also added a menu for opening the
             accompanied LazyBoy-Acronyms.txt.  It will even search your mIRC
             directory and all of it's subdirectories for it, if you decide
             to install the addon in another directory.  I have also made it
             compatible with spaces in directory names (however you should be
             using mIRC in a set of directories without spaces).

10/27/2002 - Thank you to the following people: MaNiaX (for main replacement
             code), Hardw1re (for helping me realize my code sucked and there
             was a better way of doing things), and [-T-]Kegman (for the new
             name of the script).  I have spent hours and hours on end
             developing this nice addon.  Thanks also to the beta testers who
             helped me find the 1 conflict.  I will be working on a resolve.
             Thank you also to the anonymous user who submitted a feedback
             form on my website with the idea of the colour stripping.

03/17/2002 - Updated code.  Streamlined the code a bit better.

10/11/2000 - Added more sayings
