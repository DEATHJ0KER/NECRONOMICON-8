/* WinSD Dll ********************************************************
 *
 * Version:			1.0.0.0.0
 * FileName:		winsd.dll
 * Date Created:	12/5/2001
 *
 * Author:			Soul_Eater
 * Comments:
 *		Allows user to perform windows shutdown functions
 *
 *******************************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>

//global variables
HWND mwnd;

//Logoff #2 function
int __stdcall LogOff2(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
lstrcat(data,"S_OK");
 ExitWindows(0,0);
   return 3;
}

//Shutdown function
int __stdcall ShutDown(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	ExitWindowsEx(EWX_SHUTDOWN | EWX_FORCE,0);
	 lstrcat(data,"S_OK");
   return 3;
}

//First Logoff function
int __stdcall LogOff1(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
    ExitWindowsEx(EWX_LOGOFF | EWX_FORCE,0);
  lstrcat(data,"S_OK");
	return 3;
}

//Restart function
int __stdcall Restart(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
   ExitWindowsEx(EWX_REBOOT | EWX_FORCE,0);
    lstrcat(data,"S_OK");
   return 3;
}

//nifty messagebox about info function
int MsgBox(char *data)
{
 int xa = MessageBox (mwnd , data , "WinSD DLL 1.0" , MB_OK | MB_ICONINFORMATION );
 return 0;
}

//Dll info function
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
   MsgBox("WinSD DLL 1.0 by Soul_Eater, AIM: SoulEata , Email- souleata@beer.com");
   return 0;
}
