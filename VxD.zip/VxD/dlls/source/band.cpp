//Band DLL 0.3 27/09/2003 
//XhaKeR - #SCT@PTnet
//xhaker@netmadeira.com
//All portions of code in this file were written completely by me,
//except where commented
#include "band.h"

void Signal(char *data) {	
	wsprintf(mData,"//.signal -n BD %s",data);
	SendMessage(mIRC_hwnd, WM_USER + 200,0,0);
}

VOID CALLBACK BANDR(HWND hwnd,UINT message,UINT idTimer,DWORD dwTime)
{
    ULONG x;
	x=0;
	GetIfTable(ifMIB,&s,1);
	o_get = get; o_snd = snd;
	get=snd=0;
	while (x <= ifMIB->dwNumEntries) {
		get = ifMIB->table[x].dwInOctets + get; snd = ifMIB->table[x].dwOutOctets + snd;
		x++;
	}
	o_gets = gets; o_snds = snds;
	if (xyz < 4) xyz++;
	if (xyz == 4) { gets = (get - o_get); snds = (snd - o_snd); }
}
VOID CALLBACK BANDS(HWND hwnd,UINT message,UINT idTimer,DWORD dwTime)
{   
	char text[1024]; 
	wsprintf(text,"%s [Band: %d dn %d up]", titleb, gets/1000, snds/1000); SetWindowText(mIRC_hwnd, text);
}

mIRC(band) {
	wsprintf(data,"S_OK %d %d %d %d", gets, snds, gets/1000, snds/1000);
	return 3;
}
mIRC(title) { 
	wsprintf(titleb,data);
    SetWindowText(mIRC_hwnd, titleb);
    SetTimer(mIRC_hwnd,TBAND + 1, 1000, (TIMERPROC) BANDS);
	wsprintf(data,"S_OK Titlebar_Set");
	return 3;
}
//Kamek
mIRC(icon) {
	HICON LargeIcon, SmallIcon;
	UINT Index;
	DWORD Result;
	char *FileName = data, FullName[MAX_PATH];
	HWND hWnd = mIRC_hwnd;

	if (!hWnd) return 3;
	if (!IsNumTok(&FileName, ' ', &Index))
		Index = 0;
	else if (Index > 0) Index--;

	Result = SearchPath(NULL, FileName, NULL, sizeof(FullName), FullName, NULL);
	if (Result == 0) return 3;
	if (Result > sizeof(FullName)) return 3;
	if (ExtractIconEx(FullName, Index, &LargeIcon, &SmallIcon, 1) == 0) return 3;

	if (!LargeIcon) LargeIcon = SmallIcon;
	else if (!SmallIcon) SmallIcon = LargeIcon;

	SmallIcon = (HICON)SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)SmallIcon);
	LargeIcon = (HICON)SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)LargeIcon);
	if (SmallIcon) DestroyIcon(SmallIcon);
	if (LargeIcon) DestroyIcon(LargeIcon);
	wsprintf(data,"S_OK Icon_Set");
	return 3;
}
mIRC(cicon) {
	char FullName[MAX_PATH];
	DWORD Result;

	Result = SearchPath(NULL, data, NULL, sizeof(FullName), FullName, NULL);
	if (Result == 0) return 3;
	if (Result > sizeof(FullName)) return 3;
	wsprintf(data, "S_OK %u", ExtractIconEx(FullName, -1, NULL, NULL, 1));
	return 3;
}
mIRC(menu) { 
	ULONG menun = atol(data);
	SendMessage(mIRC_hwnd, WM_COMMAND,(LPARAM) menun,0);
	wsprintf(data,"S_OK Menu_Open %d",menun);
	return 3;
}
mIRC(hide) {
	HWND _hwnd = (HWND)atol(data);
	ShowWindow(_hwnd,SW_HIDE);
	wsprintf(data,"S_OK Window_Hide");
	return 3;
}
mIRC(show) {
	HWND _hwnd = (HWND)atol(data);
    ShowWindow(_hwnd,SW_SHOW);
	wsprintf(data,"S_OK Window_Show");
	return 3;
}
mIRC(isshow) {
	HWND _hwnd = (HWND)atol(data);
	wsprintf(data,"S_OK %d",IsWindowVisible(_hwnd));
	return 3;
}
//Soul_Eater
mIRC(color) {
    CHOOSECOLOR cc;
	static DWORD rgbCurrent;
    static COLORREF clr[16];   
	COLORREF sel;
	sel = atoi(data);
	ZeroMemory(&cc, sizeof(CHOOSECOLOR));
	cc.lStructSize = sizeof( CHOOSECOLOR );
	if (data) {	
	cc.Flags = CC_FULLOPEN | CC_RGBINIT; 
	cc.rgbResult = (COLORREF)sel;
	}
	else { cc.Flags = CC_FULLOPEN; }
    cc.hwndOwner = mWnd; 
    cc.lpCustColors = (LPDWORD) clr;
   	if(ChooseColor(&cc) == TRUE)
	{
       	    rgbCurrent = cc.rgbResult; 
          	wsprintf(data,"%d",rgbCurrent);
	     	return 3;  
			}
	else 
	{
		lstrcpy(data,"$false");
		return 3;
	}
		return 3;
}
mIRC(taskbar) {
	HWND h = FindWindow("Shell_TrayWnd",NULL);
	APPBARDATA tak;
	tak.cbSize = sizeof(APPBARDATA);
	tak.hWnd = h;
	SHAppBarMessage(ABM_GETTASKBARPOS, &tak); 
	wsprintf(data,"S_OK %d %d %d %d",tak.rc.bottom,tak.rc.left,tak.rc.right,tak.rc.top);
	return 3;
}
//Epsilon
mIRC(wstyle) 
{
	char win1[900];
	wsprintf(win1,"%s",strtok(data,">"));
	HWND window = (HWND)atol(win1);
	if (IsWindow(window))
	{
		long styl = 0, exstyl = 0;
		styl = GetWindowLong(window,GWL_STYLE);
		exstyl = GetWindowLong(window,GWL_EXSTYLE);
		char temp[900];
		lstrcpy(temp,strtok(NULL," "));
		int ok = 1;
		while (ok) 
		{
			if (!lstrcmp(temp,"notitle"))	styl &= ~WS_CAPTION;
			else if (!lstrcmp(temp,"title")) styl |= WS_CAPTION;
			else if (!lstrcmp(temp,"noborder")) styl &= ~WS_BORDER;
			else if (!lstrcmp(temp,"border")) styl |= WS_BORDER;
			else if (!lstrcmp(temp,"clientedge")) exstyl |= WS_EX_CLIENTEDGE;
			else if (!lstrcmp(temp,"staticedge")) exstyl |= WS_EX_STATICEDGE;
			else if (!lstrcmp(temp,"tool")) exstyl |= WS_EX_TOOLWINDOW;
			else 
			{
				lstrcpy(data,"E_INVALID STYLE");
				return 3;
			}
			ok = 0;
			if (lstrcpy(temp,strtok(NULL," "))) ok = 1;
		}
		SetWindowLong(window,GWL_STYLE,styl);
		SetWindowLong(window,GWL_EXSTYLE,exstyl);
		SetWindowPos(window,NULL,0,0,0,0,SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOACTIVATE);
		wsprintf(data,"S_OK");
	}
	else lstrcpy(data,"E_INVALID_WINDOW");
	return 3;
}
mIRC(wtitle) {
	char win1[900], wint[900];
    wsprintf(win1,"%s",strtok(data,">"));
	lstrcpy(wint,strtok(NULL," "));
	SetWindowText((HWND)atol(win1), wint);
    lstrcpy(data,"S_OK Wtitle Set");
    return 3;
}
Proc(mIRCProc)
{
	switch(uMsg)
	{
		case WM_MOUSEMOVE: 
		{
			char s1[900];
			POINTS p1 = MAKEPOINTS(lParam);
			GetWindowText(hwnd,s1,sizeof(s1));
			wsprintf(signal,"mouseover %s %d %d",s1,p1.x,p1.y);
			Signal(signal);
            mouse.hwndTrack = hwnd;
			_TrackMouseEvent(&mouse);
			return 0;
		}
		break;

		case WM_MOUSELEAVE: 
		{
			char s1[900];
            GetWindowText(hwnd,s1,sizeof(s1));
			wsprintf(signal,"mouseleave %s",s1);
			Signal(signal);
            return 0;
		}
		break;
		/*
		case WM_CLOSE: 
		{
			SetWindowLong(hwnd,GWL_WNDPROC,(LONG) mIRC_OldProc);
			PostMessage(hwnd, uMsg,0,0);
			return 0;
		}
		break;
		*/
		default:
			break;
	}
	return CallWindowProc(mIRC_OldProc,hwnd,uMsg,wParam,lParam);
}
mIRC(watch) {
	char win1[900];
    wsprintf(win1,"%s",data);
	if ((WNDPROC)GetWindowLong((HWND)atol(win1),GWL_WNDPROC) != mIRCProc) {
		mIRC_OldProc = (WNDPROC)SetWindowLong((HWND)atol(win1),GWL_WNDPROC,(LONG)mIRCProc);
	}
	mouse.cbSize = sizeof(mouse);
    mouse.dwFlags = TME_LEAVE;
    mouse.dwHoverTime = NULL;
    mouse.hwndTrack = (HWND)atol(win1);
    _TrackMouseEvent(&mouse);
    lstrcpy(data,"S_OK watching");
	return 3;
}

mIRC(version) 
{
	ret("Band DLL v0.5 by XhaKeR �2003 - http://www.xpro.tk");
}

void WINAPI LoadDll(LOADINFO* load)
{	
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");     
    mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	mIRC_hwnd = load->mHwnd;
	load->mKeep = TRUE; 
	o_get = o_snd = snd = get = gets = snds = o_gets = o_snds = xyz = s = 0;
	GetIfTable(0,&s,1); 
	ifMIB = (PMIB_IFTABLE)malloc((size_t)s);
	SetTimer(mIRC_hwnd,TBAND, 1000, (TIMERPROC) BANDR);
}

int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
  {
	  KillTimer(mIRC_hwnd, TBAND);
      KillTimer(mIRC_hwnd, TBAND + 1);
      UnmapViewOfFile(mData);
	  CloseHandle(hFileMap);
	  return 1;
	}
  else return 0;
}