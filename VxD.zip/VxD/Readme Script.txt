﻿;=====================================================================================================================================;
; info script | VxÐ ~ https://vxd.mobi ~ http://vxd.altervista.org ~ caronte.ade@gmail.com |  mIRC VxÐ $¢®iþt 2005-2020               ;
; Author: Valentino Decaroli aka VxD aka DEATHJ0KER                                                                                   ;
; Necronomicon 8 Vers.8 Rev.50 01/01/2020                                                                                             ;                                                                                                                                                                                                                                                                 ;
;=====================================================================================================================================;

; thanks to...

; Ook ■ http://www.mircscripting.info/
; for fix DCX.dll and Treebar script... for your suggestions to mIRC help

; hixxy ■ for your suggestions to mIRC help - http://forums.mirc.com/ubbthreads.php/topics/241033/mIRC_variables_set_by_/writein and version $os

; Talon for your suggestions to mIRC help - treebarinfo ■ http://forums.mirc.com/ubbthreads.php/topics/251981/Re:_Treebar_position 

; MTX ■ https://sites.google.com/site/mtxproject/
; for your suggestions to help xPopups

; Ford_Lawnmower ■ irc.mindforge.org #USA-Chat 
; addon: (style UTF8 )

; ## #Flobse @ Quakenet - Scripter@Flobse.de ■ Gummibaer www.central-irc.de
; suggestions  ~ structure of many popups menu created with  (xPopups Converter by Flobse)

; Kane-II ■ http://www.godirc.tk/
; Translations colorful code fun phrases

; ■ Yet thanks to the publishers of other codes addons included in this script